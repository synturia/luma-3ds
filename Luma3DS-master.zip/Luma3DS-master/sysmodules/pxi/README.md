# 3ds_pxi
Open source replacement of the Arm11 PXI system module.
This is licensed under the MIT license.

# Usage
To run this system module, use a recent release or commit of [Luma3DS](https://github.com/LumaTeam/Luma3DS/) and copy pxi.cxi to /luma/sysmodules/.

# Credits
This list is not complete at all:

* @Subv, for the process patch that used to be used in Luma3DS which I modified to assist me in PXI sysmodule reverse-engineering
* @yifanlu, for the work his own work on loader
* @Mrrraou, for intensive testing back in June/July 2016
* @jackron, for makerom support and help
* Many #Cakey and #3dsdev folks I haven't mentioned here, etc.
