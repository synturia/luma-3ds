#pragma once

void processMonitor(void *p);
