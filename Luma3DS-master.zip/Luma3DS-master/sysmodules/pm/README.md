# 3ds_pm
Open source replacement of the Arm11 PM system module.
This is licensed under the MIT license.

# Usage
To run this system module, use a recent release or commit of [Luma3DS](https://github.com/LumaTeam/Luma3DS/), build this project and copy the generated CXI file to `/luma/sysmodules/pm.cxi`.

# Credits
@fincs
@Stary
