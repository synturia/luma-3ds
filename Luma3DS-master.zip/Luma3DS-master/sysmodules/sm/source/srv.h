/*
srv.h

(c) TuxSH, 2017-2020
This is part of 3ds_sm, which is licensed under the MIT license (see LICENSE for details).
*/

#pragma once

#include "common.h"

Result srvHandleCommands(SessionData *sessionData);
