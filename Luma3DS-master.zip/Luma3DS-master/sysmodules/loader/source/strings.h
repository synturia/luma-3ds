#pragma once

#include <3ds/types.h>
#include <string.h>

void progIdToStr(char *strEnd, u64 progId);
