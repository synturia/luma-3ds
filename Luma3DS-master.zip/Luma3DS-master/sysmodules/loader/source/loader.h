#pragma once

#include <3ds/types.h>

void loaderHandleCommands(void *ctx);
